[RU]
Официальный шрифт GTA San Andreas

Официальный шрифт GTA San Andreas.
Поместите из архива файл OLDENGL.TTF в системную папку Fonts, вашей Windows: C:\Windows\Fonts\

Скачать Официальный шрифт GTA San Andreas OLDENGL.TTF вы можете на этой странице, перейдя по любой из ссылок на скачивание.

https://www.gtavicecity.ru/gta-san-andreas/programs/23100-oficialnyy-shrift-gta-san-andreas.html

################################################################################################

[EN]
The official font for GTA San Andreas

The official font GTA San Andreas.
Place from the archive file OLDENGL.TTF in system Fonts folder, your Windows: C:\Windows\Fonts\

Download: OLDENGL.TTF

https://www.gtaall.com/gta-san-andreas/programs/23100-oficialnyy-shrift-gta-san-andreas.html

################################################################################################

[FR]
La police officielle pour GTA San Andreas

La police officielle pour GTA San Andreas.
Placez le fichier OLDENGL de l'archive.Polices TTF dans votre dossier système, vos fenêtres : C:\Windows\Fonts\

Télécharger : OLDENGL.TTF

https://www.gtaall.eu/fr/gta-san-andreas/programs/23100-oficialnyy-shrift-gta-san-andreas.html

################################################################################################

[DE]
Die offizielle Schrift für GTA San Andreas

Die offizielle Schrift für GTA San Andreas.
Legen Sie die OLDENGL-Datei aus dem Archiv.TTF-Fonts auf Ihrem System-Ordner Ihres Windows: C:\Windows\Fonts\

Download: OLDENGL.TTF

https://www.gtaall.eu/de/gta-san-andreas/programs/23100-oficialnyy-shrift-gta-san-andreas.html

################################################################################################

[ES]
La fuente oficial para el GTA San Andreas

La fuente oficial para el GTA San Andreas.
Coloque el archivo OLDENGL del archivo.Fuentes TTF a la carpeta del sistema, Windows: C:\Windows\Fonts\

Descargar: OLDENGL.TTF

https://www.gtaall.net/gta-san-andreas/programs/23100-oficialnyy-shrift-gta-san-andreas.html

################################################################################################

[PT]
A fonte oficial para o GTA San Andreas

A fonte oficial para o GTA San Andreas.
Coloque o arquivo OLDENGL do arquivo.Fontes TTF para a pasta do sistema, seu Windows: C:\Windows\Fonts\

Baixar: OLDENGL.TTF

https://www.gtaall.com.br/gta-san-andreas/programs/23100-oficialnyy-shrift-gta-san-andreas.html